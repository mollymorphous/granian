// Repeat text so there's something to compress
console.log("Line 1");
console.log("Line 2");
console.log("Line 3");
console.log("Line 4");
